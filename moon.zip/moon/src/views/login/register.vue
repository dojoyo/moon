<template>
	<div id="register">
		<mt-header fixed title="注册账号">
			<router-link to="/logins" slot="left">
				<mt-button icon="back"></mt-button>
			 </router-link>
		</mt-header>
		<section id="main">
			<mt-field  placeholder="请输入手机号码" type="tel" v-model="user.phone"></mt-field>

			<span v-show="isphone" v-bind:class="{iscorrect:isphone}">请输入正确格式的手机号码</span>

			<mt-field  placeholder="请输入密码" type="password" v-model="user.password"></mt-field>
			<span v-show="ispass" v-bind:class="{isright:ispass}">请6-15位的数字大小写字母组成的密码</span>
			<mt-field label="验证码" v-model="user.captcha" >
				<span @click="captcha()">获取验证码</span>
			</mt-field>
			<span v-show="iscaptcha" v-bind:class="{isright:iscaptcha}">验证码不能为空</span>
			<mt-button type="danger" size="large" @click="sure()">确认</mt-button>
		</section>
	</div>
</template>
<script>
	export default{
		name:'register',
		data(){
			return{
				user:{
					'phone':'',
					'password':'',
					'captcha':''
				},
				isphone:false,//手机号码错误显示
				ispass:false, //密码错误显示
				iscaptcha:false//验证码

				// captcha:
			}
		},
		methods:{
			captcha:function(){
				var phone = /^1(3|4|5|7|8)\d{9}$/;//验证手机号码
				// 判断是否有手机号码
				if(!phone.test(this.user.phone)){
					this.isphone=true;
				}else{
					this.isphone=false;
					this.$ajax({
						method:'get',
						url:'/api/doctor/common/send_code?phone='+this.user.phone,
					}).then(function(data){
							console.log(data)
							console.log('这是验证码')
						})
				}
				
			},
			sure:function(){
				// console.log(this.user)
				var phone = /^1(3|4|5|7|8)\d{9}$/;//验证手机号码
				var pass =/^[a-zA-Z0-9]{6,15}$/;//验证密码
				var captcha=/^[0-9]{6}$/

				// 判断手机号码和密码格式是否正确
				if(!phone.test(this.user.phone)){
					this.isphone=true;
				}else{
					this.isphone=false;
				}
				//判断密码是否正确
				if(!pass.test(this.user.password)){
					this.ispass=true;	
				}else{
					this.ispass=false;	
				}
				//判断验证码是否为空
				
				if(this.user.captcha=='' && !captcha.test(this.user.captcha)){
					this.iscaptcha=true
				}else{
					this.$ajax({
						method:'get',
						url:'/api/doctor/common/verify_code_match?phone='+this.user.phone + '&code=' + this.user.captcha,
					}).then(function(captcha){
							console.log(captcha);
							console.log('captcha')
					})
				}

				//提交用户信息
				if(phone.test(this.user.phone) && pass.test(this.user.password)){
						
					delete this.user.captcha;

					this.$ajax({
						method:'post',
						url:'/api/user/user/phone_sign_in',
						data:{
							phone:this.user.phone,
							password:this.user.password
						}
					}).then(function(data){
							console.log(data);
							console.log('data');
								if(data.data.err_code==0){
									alert('注册成功');
									setTimeout(function(){
										window.location.href = '/logins'
									},1000)
								}else{
									this.isphone=true;
								}
						})
				}

				
				
			}
		}
	}
</script>
<style>
	.mint-button--large{margin:30px auto;width:80%;}
	.iscorrect,.isright{
		display: block;
	    color: #CC0D0D;
	    padding-left: 10px;
	}
</style>