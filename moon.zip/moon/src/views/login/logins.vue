<template>
	<div id="login">
		<div class="title tc mb30">登录</div>
		<section id="Main" class="tc">
			<mt-field type="tel " placeholder="请输入用户名" v-model="user.phone"></mt-field>

			<span v-show="isphone" v-bind:class="{iscorrect:isphone}">请输入正确格式的手机号码</span>

			<mt-field type="password" placeholder="请输入密码" v-model="user.password"></mt-field>

			<span v-show="ispass" v-bind:class="{isright:ispass}" >请6-15位的数字大小写字母组成的密码</span>

			<router-link class="forget" to="/login/forget" >忘记密码</router-link>

			<router-link class="register" to="/login/register">注册账号</router-link>

			<mt-button type="danger"  @click="submit()" class="submit" >登录</mt-button>
		</section>
	</div>
</template>
<script>
	export default{
		data(){
			return{
				user:{
					"phone":'',
					'password':''
				},
				isphone:false,
				ispass:false
			}
		},
		methods:{
			submit:function(){
				var phone = /^1(3|4|5|7|8)\d{9}$/;
				var pass =/^[a-zA-Z0-9]{6,15}$/;

				// 判断手机号码和密码格式是否正确
				if(!phone.test(this.user.phone)){
					this.isphone=true;
				}else{
					this.isphone=false;
				}
				if(!pass.test(this.user.password)){
					this.ispass=true;	
				}else{
					this.ispass=false;	
				}
				if(phone.test(this.user.phone) && pass.test(this.user.password)){
						
					this.$ajax({
						method:'post',
						url:'/api/user/user/user_login',
						data:{
							phone:this.user.phone,
							password:this.user.password
						}
					}).then(function(data){
							console.log(data);
							console.log('data');
								if(data.data.err_code==0){
									window.localStorage.setItem('kb_code',JSON.stringify(data))
									window.location.href="/information"
								}else if(data.data.err_code==54){
									alert(data.data.err_msg)

								}
						})
				}
			}
		}
	}
</script>
<style>
	.title{font:18px microsoft yahei;}
	.mint-cell-wrapper{border-bottom:1px solid #eee;background-image:none;}
	.mint-cell:first-child .mint-cell-wrapper{background-origin: none}
	.submit{margin:30px auto;width:80%;}
	.mint-field-core{font-size: 10px}
	.forget,.register{display:inline-block;font-size:10px;margin-top:20px;padding:0 10px;text-decoration: none}
	.forget{float:left;color:#888;}
	.register{float:right;color:#ff9194;}
	.mint-cell-left:nth-child(1) + .mint-cell-wrapper{    font-size: 10px;
    display: inline-block;
    float: left;
}
</style>
