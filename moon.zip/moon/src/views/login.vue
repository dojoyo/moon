<template>
	<div id="login">
		<mt-field type="text" placeholder="请输入用户名" v-model="user.name"></mt-field>
		<mt-field type="password" placeholder="请输入密码" v-model="user.pass"></mt-field>

		<!-- <me-cell> -->
			<a class="forget" href="javascript:void(0)">忘记密码</a>
			<a class="register" href="javascript:void(0)">注册账号</a>
		<!-- </me-cell> -->
		
		<mt-button type="danger"  @click="submit()" class="submit" to="./homepage/index.vue">登录</mt-button>
	</div>
</template>
<script>
	export default{
		data(){
			return{
				user:{
					"name":'',
					'pass':''
				}
			}
		},
		methods:{
			submit:function(){
				this.$router.replace({path:'/index'})
			}
		}
	}
</script>
<style>
	.mint-cell-wrapper{border-bottom:1px solid #eee;background-image:none;}
	.mint-cell:first-child .mint-cell-wrapper{background-origin: none}
	.submit{margin-top:30px;width:80%;}
	.mint-field-core{font-size: 10px}
	.forget,.register{display:inline-block;font-size:10px;margin-top:20px;padding:0 10px;}
	.forget{float:left;color:#888;}
	.register{float:right;color:#ff9194;}
</style>
