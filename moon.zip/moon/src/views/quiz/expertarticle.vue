<template>
	<div id="expertarticle">
		<mt-header fixed title="专家文章">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				<mt-button icon="more"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-cell title="出生的宝爸的10大健康保障" class="p20">
			  <!-- <span>icon 是图片</span> -->
			  <img  src="../../../static/images/1.jpg" width="100" height="80" class="pa">
			  <p class="kb_cell-brief pa">2017-03-12 
	            <i class="ml10 icon-look w20 h20"></i>
	            <span>100</span>
	          </p>
			</mt-cell>
			<mt-cell title="出生的宝爸的10大健康保障">
			  <!-- <span>icon 是图片</span> -->
			  <img  src="../../../static/images/1.jpg" width="100" height="80" class="pa">
			  <p class="kb_cell-brief pa">2017-03-12 
	            <i class="ml10 icon-look w20 h20"></i>
	            <span>100</span>
	          </p>
			</mt-cell>
			<mt-cell title="出生的宝爸的10大健康保障">
			  <!-- <span>icon 是图片</span> -->
			  <img  src="../../../static/images/1.jpg" width="100" height="80" class="pa">
			  <p class="kb_cell-brief pa">2017-03-12 
	            <i class="ml10 icon-look w20 h20"></i>
	            <span>100</span>
	          </p>
			</mt-cell>

		</section>
	</div>
</template>

<style>
	.mint-cell{top:60px;}
	.mint-cell-wrapper{display: block;padding: 20px 10px}
	.mint-cell-value{position:relative;height:60px;}
	.mint-cell-value img{right:0;top:-16px;}
	.kb_cell-brief{bottom:0;}
</style>