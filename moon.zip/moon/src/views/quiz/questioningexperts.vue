<template>
	<div id="questioningexperts">
		<mt-header fixed title="选择提问的医生">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-cell  title="百伦费  主治医生" label="没故意和复查可" class="moon-bc">
				<span class="moon_btnMini-main pa w50 h30 tc pr10 f12">10元/次</span>
				<span class="pa moon_btnMini moon_btnMini-biref">被提问13次</span>
		    	<img src="../../../static/images/1.jpg" class="round-img fl mr10" slot="icon" >

		    	<div class="good mt10 mb10 ">
		    		数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					2,用户名称均显示第一个文字,其余字用"*"号代替
					3,点击用户名称不可跳转至该用户的主页面
		    	</div>
			</mt-cell>
			<mt-tabbar fixed>
				 <mt-tab-item>
				 	<mt-button type="danger" size="large">支付20元</mt-button>
				  </mt-tab-item>
			</mt-tabbar>
			
		</section>
	</div>
</template>
<style>
	.moon-bc .mint-cell-wrapper{display: block}
.moon-bc .mint-cell-title{height:50px;}
.moon_btnMini-main{display:inline-block;border-radius:10px;right:15px;top:6px;line-height: 30px}
.moon_btnMini{left:160px;top:22px;font-size: 12px}
.mint-tabbar{background: none}
#foot{display: none}
</style>