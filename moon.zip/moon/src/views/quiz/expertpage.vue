<template>
	<div id="expertpage">
		<mt-header title="专家主页">
		  <router-link to="/" slot="left">
		    <mt-button icon="back"></mt-button>
		  </router-link>
		</mt-header>
		<section id="Main">
				<!-- 医生简介 -->
			<mt-cell  title="百伦费  主治医生" label="没故意和复查可" class="moon-bc">
				<span class="moon_btnMini-main pa w50 h30 tc pr10">关注</span>
				<span class="pa moon_btnMini moon_btnMini-biref">被提问13次</span>
		    	<img src="../../../static/images/1.jpg" class="round-img fl mr10" slot="icon" >

		    	<div class="good mt10 mb10 ">
		    		数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					2,用户名称均显示第一个文字,其余字用"*"号代替
					3,点击用户名称不可跳转至该用户的主页面
		    	</div>
			</mt-cell>
			<!-- 医生自我介绍 -->
			<mt-cell title="自我介绍" class="intro">
				数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					2,用户名称均显示第一个文字,其余字用"*"号代替
					3,点击用户名称不可跳转至该用户的主页面
			</mt-cell>
			<mt-cell title="他的文章" value="239篇" is-link></mt-cell>
			<!-- 用户评论 -->
			<div class="com">
				<span class="recom-title pl10 mb10">用户评论</span>
				<mt-cell title="username">
					<span class="kb_cell-brief pa">2017-12 12:30</span>
					<div class="dl_bc-biref mt10">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
				</mt-cell>
			</div>
			<div class="com">
				<span class="recom-title pl10 mb10">用户评论</span>
				<mt-cell title="username">
					<span class="kb_cell-brief pa">2017-12 12:30</span>
					<div class="dl_bc-biref mt10">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
				</mt-cell>
			</div>
			<div class="com">
				<span class="recom-title pl10 mb10">用户评论</span>
				<mt-cell title="username">
					<span class="kb_cell-brief pa">2017-12 12:30</span>
					<div class="dl_bc-biref mt10">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
				</mt-cell>
			</div>
			<mt-cell title="查看全部评论 >" class="tc"></mt-cell>
		</section>
	</div>
</template>
<script>
	export default{
		name:'expertpage',
		data(){
			return{

			}
		},
		methods:{

		}
	}
</script>
<style>
	
.moon-bc .mint-cell-wrapper,.intro .mint-cell-wrapper,.com .mint-cell-wrapper{
	display: block
}
.moon-bc .mint-cell-title{
	height:50px;
}
.intro .mint-cell-value,.com .mint-cell-value{
	position:relative;
	min-height:90px;
}
.moon_btnMini-main{display:inline-block;border-radius:10px;right:15px;top:6px;line-height: 30px}
.moon_btnMini{left:160px;top:22px;font-size: 12px}
.intro .mint-cell-text,.com .mint-cell-text,{display:block;color:#ff9194;font-size: 12px;padding-bottom: 5px}
.dl_bc-biref{
	    line-height: 23px;
    font-size: 14px;
    padding: 10px;
    border-radius: 10px;
}
.com .recom-title{display: block}
.kb_cell-brief{right:15px;top:-15px;}
/*.tc{color:#4e93e2;}*/
</style>