<template>
	<div id="allcomment">
		<mt-header title="全部评论">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<div class="com mt20">
				<mt-cell title="username">
					<span class="kb_cell-brief pa">2017-12 12:30</span>
					<div class="dl_bc-biref mt10">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
				</mt-cell>
			</div>
			<div class="com mt20">
				<mt-cell title="username">
					<span class="kb_cell-brief pa">2017-12 12:30</span>
					<div class="dl_bc-biref mt10">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
				</mt-cell>
			</div>
		</section>
	</div>
</template>
<style>
.com .mint-cell-wrapper{
	display: block;
	border:none;
}
.com .mint-cell-value{
	position:relative;
	min-height:90px;
}
.kb_cell-brief{right:15px;top:-15px;}
.dl_bc-biref{
	    line-height: 23px;
    font-size: 14px;
    padding: 10px;
    border-radius: 10px;
}
</style>