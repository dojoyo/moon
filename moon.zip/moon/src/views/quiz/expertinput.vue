<template>
	<div id="expertinput">
		<mt-header title="提问">
		  <router-link to="/" slot="left">
		    <mt-button icon="back"></mt-button>
		  </router-link>
		</mt-header>
		<section id="Main">
			<mt-cell  title="百伦费  主治医生" label="没故意和复查可" class="moon-bc p10">
		    	<img src="../../../static/images/1.jpg" class="round-img fl mr10" slot="icon" >
			</mt-cell>
			<div class="moon-bc">
				<h2 class="f18 mb10 pl10">症状描述</h2>
				<mt-field placeholder="请将你的问题描述的越清楚越好" type="textarea" rows="8">
					<span>0/200</span>
				</mt-field>
				<h2 class="f18 mb10 pl10">上传照片</h2>
				<label class="kb_fileBox ml10">
					<input type="text/submit/hidden/button/etc" name="" value="" class="kb_file">
					<span class="kb_file-btn"></span>
				</label>
			</div>
			<div class="kb_cells moon-bc p10 ">
				<span class="recom-title mb10">咨询提示</span>
				<mt-cell>
					<ol class="kb_ol">
						<li>咨询专家的时间为48小时内。</li>
						<li>超过48小时未解答，将按支付路径全额退款。</li>
					</ol>
				</mt-cell>
			</div>
		</section>
		<mt-tabbar fixed id="pay">
			<mt-tab-item >
			   
				<a class="kb_btn moon_btn-main  f15 bc">
					￥支付10元
				</a>
			  </mt-tab-item>
			
		</mt-tabbar>
	</div>
</template>
<style>
	.mint-field-core{font-size: 12px;border:1px solid #eee;padding:10px;}
	.mint-field-other span{
		position: absolute;
    top: 68px;
    right: 30px;
    font-size: 12px;
    color: #999;
	}
	ol.kb_ol>li{
		font-size: 14px;
		line-height: 20px;
	}
	.mint-tabbar > .mint-tab-item.is-selected{background-color: #ff9194}
	#foot{display: none}
</style>