<template>
	<div id="expertlist">
		<mt-header  fixed>
			<mt-search slot="left">
			  <mt-cell>
			  </mt-cell>
			</mt-search>

			<router-link to="#" slot="right">
				<span class="icon-msg"></span>
			</router-link>
		</mt-header>
		<section id="main">
	<!-- 		<div class="nav mb15">  
			      <mt-button size="small" @click.switch.native.prevent="active = 'Nursing'" class="subject">护理</mt-button>  
			      <mt-button size="small" @click.switch.native.prevent="active = 'Psychology'">心粒</mt-button>  
			      <mt-button size="small" @click.switch.native.prevent="active = '3'">营养</mt-button> 
			      <mt-button size="small" @click.switch.native.prevent="active = '4'">儿童</mt-button>  
			      <mt-button size="small" @click.switch.native.prevent="active = '5'">妇产</mt-button>  
		    </div> 
		    <div class="page-tab-container">
				<mt-tab-container v-model="active" swipeable>
					  <mt-tab-container-item id="Nursing">
					    <mt-cell  v-for="n in 5" title="百伦费主治医生" label="没故意和复查可">
					    	<img src="../../../static/images/1.jpg" class="round-img fl" slot="icon">
					    	<div class="good mt10 mb10">
					    		数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
								2,用户名称均显示第一个文字,其余字用"*"号代替
								3,点击用户名称不可跳转至该用户的主页面
					    	</div>

					    </mt-cell>

					  </mt-tab-container-item>
					  <mt-tab-container-item id="Psychology">
					    <mt-cell  title="Psychology 2" v-for="n in 5"></mt-cell>
					  </mt-tab-container-item>
					  <mt-tab-container-item id="3">
					    <mt-cell  title="tab-container 3" v-for="n in 5"></mt-cell>
					  </mt-tab-container-item>
					   <mt-tab-container-item id="4">
					    <mt-cell  title="tab-container 4" v-for="n in 5"></mt-cell>
					  </mt-tab-container-item>
					   <mt-tab-container-item id="5">
					    <mt-cell  title="tab-container 5" v-for="n in 5"></mt-cell>
					  </mt-tab-container-item>
				</mt-tab-container>
			</div> -->

			<mt-navbar v-model="selected">
			  <mt-tab-item id="1">选项一</mt-tab-item>
			  <mt-tab-item id="2">选项二</mt-tab-item>
			  <mt-tab-item id="3">选项三</mt-tab-item>
            </mt-navbar>
			<!-- tab-container -->
			<mt-tab-container v-model="selected">
			  <mt-tab-container-item id="1">
			   <mt-cell  v-for="n in 5" title="百伦费主治医生" label="没故意和复查可">
					    	<img src="../../../static/images/1.jpg" class="round-img fl" slot="icon">
					    	<div class="good mt10 mb10">
					    		数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
								2,用户名称均显示第一个文字,其余字用"*"号代替
								3,点击用户名称不可跳转至该用户的主页面
					    	</div>

					    </mt-cell>
			  </mt-tab-container-item>
			  <mt-tab-container-item id="2">
			    <mt-cell v-for="n in 4" :title="'测试 ' + n" />
			  </mt-tab-container-item>
			  <mt-tab-container-item id="3">
			    <mt-cell v-for="n in 6" :title="'选项 ' + n" />
			  </mt-tab-container-item>
			</mt-tab-container>
		</section>
	</div>
</template>
<script>
	export default{
		name:'expertlist',
		data(){
			return{
				selected:'1'
			}
		},
		methods:{
			switch:function(){
				console.log('3333')
			}
		},
		watch:{
			active:function(id){
				console.log(id)

				$('#'+id).css({'border-bottom':'2px solid #ff9194','color':'#ff9a94'})
			}
		}
	}
</script>
<style>
	.mint-button{
	    background: transparent;
		/*border-bottom: 2px solid #ff9194 ;*/
		border-radius: 0 ;
		width:60px;
		margin:0 5px 0 6px;
	}
	.mint-button--default {
		background-color: transparent;
		box-shadow: none;
	}
	.mint-cell-text{
		display:block;
		margin-bottom: 10px;
		margin-top:5px;
	}
	.mint-cell-title{
		border-bottom:1px solid #eee;
		padding-bottom: 10px
	}
	 .mint-cell-wrapper{
		display: grid;
		border: none
	}
</style>