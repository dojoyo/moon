<template>
	<div id="allcomment">
		<mt-header fixed title="全部评论">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				<mt-button icon="more"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<div class="p10 com">
				<mt-cell title="hahah" class="dynamic mt10">
					<span class="kb_cell-time pa" slot="icon">8:00</span>

					<div class="dl_bc-biref mt10 pa">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
					<img src="../../../static/images/1.jpg" class="w50 h50 round-img" slot="icon">
					<p class="pa pic">
					  <img src="../../../static/images/1.jpg" class="w150 h90">
					  <img src="../../../static/images/1.jpg" class="w150 h90">
					</p>
				</mt-cell>
				<mt-cell title="hahah" class="dynamic mt10">
					<span class="kb_cell-time pa" slot="icon">8:00</span>

					<div class="dl_bc-biref mt10 pa">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
					<img src="../../../static/images/1.jpg" class="w50 h50 round-img" slot="icon">
					<p class="pa pic">
					  <img src="../../../static/images/1.jpg" class="w150 h90">
					  <img src="../../../static/images/1.jpg" class="w150 h90">
					</p>
				</mt-cell>
			</div>
		</section>
	</div>
</template>
<style>
		.com .dl_bc-biref{
		top:64px;
		 line-height: 23px;
	    font-size: 14px;
	    padding: 10px;
	    border-radius: 10px;
	    min-height: 50px
	}
	.dynamic .mint-cell-wrapper{
		min-height:250px;
		position:relative;
		border:none;
	}
	 .dynamic .kb_cell-time{top:32px;left:60px;}
	 .dynamic .mint-cell-title{position:absolute;top:0;width:100%;}
	 .dynamic .kb_cell-brief{top:45px;}
	 .pic{bottom:0;}
</style>