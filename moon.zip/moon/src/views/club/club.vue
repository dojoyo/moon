<template>
	<div id="club">
		<mt-header  fixed title="月子会所">
			<mt-search slot="left">
			  <mt-cell>
			  </mt-cell>
			</mt-search>

			<router-link to="#" slot="right">
				<span class="icon-msg"></span>
			</router-link>
		</mt-header>
		<section id="Main">
			<div class="club">
				<span class="local tc">定位</span>
				<span class="local tc">区域</span>
				<span class="local tc">筛选</span>
			</div>
			<mt-cell title="优诺家月子会所">
				 <p class="kb_cell-brief fr" slot="icon">
		            <i class="ml10 icon-look w20 h20"></i>
		            <span>100</span>
		          </p>
		          <img src="../../../static/images/1.jpg" class="w h200">
		          <p class="pt10 f12">广州市海珠区广州大道版</p>
			</mt-cell>
			<mt-cell title="优诺家月子会所">
				 <p class="kb_cell-brief fr" slot="icon">
		            <i class="ml10 icon-look w20 h20"></i>
		            <span>100</span>
		          </p>
		          <img src="../../../static/images/1.jpg" class="w h200">
		          <p class="pt10 f12">广州市海珠区广州大道版</p>
			</mt-cell>
		</section>
	</div>
</template>
<style>
	.local{
		width: 32%;
	    display: inline-block;
	    font-size: 14px;
	    
	}
	.kb_cell-brief{display: inline-block;}
.mint-cell-wrapper,.mint-cell-value{
	display: block;
	padding:10px;
}
.mint-cell-title{padding:20px 10px;}
</style>