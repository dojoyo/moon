<template>
	<div id="detailedpackage">
		<mt-header  fixed title="优诺家月子会所">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				<mt-button icon="more"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-swipe :auto="4000" continuous>
			  <mt-swipe-item>1</mt-swipe-item>
			  <mt-swipe-item>2</mt-swipe-item>
			  <mt-swipe-item>3</mt-swipe-item>
			</mt-swipe>
			<mt-cell title="优诺家月子会所" label="广州大道南苏州市" class="intro">
				 <p class="kb_cell-brief fr" slot="icon">
		            <i class="ml10 icon-look w20 h20"></i>
		            <span>100</span>
		          </p>
		          <div class="good mt10 mb10">
					    		数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
								2,用户名称均显示第一个文字,其余字用"*"号代替
								3,点击用户名称不可跳转至该用户的主页面
					<span class="f12 clearfix tr mt10">查看更多&nbsp;></span>
					<p class="tc btop mt10 pt10">
						<img src="../../../static/images/usermoon/@1x/mh-phone.png" class="w50 h50">
					</p>
				</div>
			</mt-cell>
		</section>
		<div class="footer">
			<mt-tabbar fixed>
		        <mt-tab-item id="homepage">
			        <img slot="icon" src="../../../static/css/img/usermoon/@1x/footer/mh-Customer-service-default.png" height="47" width="50">
			          首页
			      </mt-tab-item>
			      <mt-tab-item id="imformation">
			        <img slot="icon" src="../../../static/css/img/usermoon/@1x/footer/mh-Collection-defulat.png" height="47" width="50">
			       客服
			      </mt-tab-item>
			      <mt-tab-item id="quiz">
			        <img slot="icon" src="../../../static/css/img/usermoon/@1x/footer/mh-comment.png" height="47" width="50">
			        预约到店
			      </mt-tab-item>
			 </mt-tabbar>
		</div>
	</div>
</template>
<style>
	.mint-swipe,.mint-swipe-item,.mint-swipe-items-wrap > div.is-active{width:100%;height:200px;background-color: #f00}
	.mint-cell-wrapper{display:block;border:none;}
	.intro .mint-cell-title{height:50px;padding:10px 0;border-bottom:1px solid #eee;}
	.server .mint-cell-value{display: block}
	.server{display:inline-block;}
	#foot{display: none}
	.mint-tab-item-label{vertical-align: middle;}
	.mint-tab-item-label{display: inline-block}
</style>