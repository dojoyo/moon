<template>
	<div id="introduction">
		<mt-header fixed title="会所简介">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				<mt-button icon="more"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-cell>
				<div class="intro mb10 f14">
					环境下爱神的箭撒谎大家撒活动就撒谎合肥市几号放假按时打卡回复即可收到回复发货及时的回复继父回家快递师傅介绍的客户方决定是否决定是否就是快发货时间发货时间看到
				</div>
				<img src="../../../static/images/1.jpg" class="w ">
			</mt-cell>
		</section>
	</div>
</template>
<style>
	.mint-cell-value{display: block}
	.mint-cell-wrapper{border:none;}
	.intro{line-height: 20px}
</style>