<template>
	<div id="comment">
		<mt-header fixed title="发表评论">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				发布
			</router-link>
		</mt-header>
		<section id="Main">
			
			<mt-checklist
			  align="right"
			  title="右对齐"
			  v-model="value"
			  :options="options">
			</mt-checklist>
		</section>
	</div>
</template>
<script>
	export default{
		name:'comment',
		data(){
			return{
				//存放所选选项  
            value:[],  
            //checklist设置  
            options : [{  
	            label: '选项A',  
	            value: 'A',  
	            disabled: true  //可以禁用选项  
	            },  
	            {  
	            label: '选项B',  
	            value: 'B',  
	            disabled: true  
	            },  
	            {  
	            label: '选项C',  
	            value: 'C'  
	            },  
	            {  
	            label: '选项D',  
	            value: 'D'  
	            }]  
				}
			}
	}
</script>