<template>
	<div id="clubdetail">
		<mt-header  fixed title="优诺家月子会所">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-swipe :auto="4000" continuous>
			  <mt-swipe-item>1</mt-swipe-item>
			  <mt-swipe-item>2</mt-swipe-item>
			  <mt-swipe-item>3</mt-swipe-item>
			</mt-swipe>
			<mt-cell title="优诺家月子会所" label="广州大道南苏州市" class="intro">
				 <p class="kb_cell-brief fr" slot="icon">
		            <i class="ml10 icon-look w20 h20"></i>
		            <span>100</span>
		          </p>
		          <div class="good mt10 mb10">
					    		数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
								2,用户名称均显示第一个文字,其余字用"*"号代替
								3,点击用户名称不可跳转至该用户的主页面
					<span class="f12 clearfix tr mt10">查看更多&nbsp;></span>
					<p class="tc btop mt10 pt10">
						<img src="../../../static/images/usermoon/@1x/mh-phone.png" class="w50 h50">
					</p>
				</div>
			</mt-cell>
			<div>
				<h2 class="pl10 pb10">本店服务</h2>
				<mt-cell class="server">
					<img src="../../../static/images/1.jpg" class="w150 h90">
					<p class="pt10 pb10">小月子套餐</p>
					<p>
						<span class="mr10">￥320</span><span class="f12">320</span>
					</p>
				</mt-cell>
				<mt-cell class="server">
					<img src="../../../static/images/1.jpg" class="w150 h90">
					<p class="pt10 pb10">小月子套餐</p>
					<p>
						<span class="mr10">￥320</span><span class="f12">320</span>
					</p>
				</mt-cell>
				<mt-cell class="server">
					<img src="../../../static/images/1.jpg" class="w150 h90">
					<p class="pt10 pb10">小月子套餐</p>
					<p>
						<span class="mr10">￥320</span><span class="f12">320</span>
					</p>
				</mt-cell>
			</div>
			<div class="p10 com">
				<span class="recom-title">用户评论</span>
				<mt-cell title="hahah" class="dynamic mt10">
					<span class="kb_cell-time pa" slot="icon">8:00</span>

					<div class="dl_bc-biref mt10 pa">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
					<img src="../../../static/images/1.jpg" class="w50 h50 round-img" slot="icon">
					<p class="pa pic">
					  <img src="../../../static/images/1.jpg" class="w150 h90">
					  <img src="../../../static/images/1.jpg" class="w150 h90">
					</p>
				</mt-cell>
				<mt-cell title="hahah" class="dynamic">
					<span class="kb_cell-time pa" slot="icon">8:00</span>

					<div class="dl_bc-biref mt10 pa">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
					<img src="../../../static/images/1.jpg" class="w50 h50 round-img" slot="icon">
					<p class="pa pic">
					  <img src="../../../static/images/1.jpg" class="w150 h90">
					  <img src="../../../static/images/1.jpg" class="w150 h90">
					</p>
				</mt-cell>
				<p class="tc mt10">
					<router-link to="#" class="moon-href">查看所有评论</router-link>
				</p>
			</div>
		</section>
		<div class="footer">
			<mt-tabbar fixed>
		        <mt-tab-item id="homepage">
			        <img slot="icon" src="../../../static/css/img/usermoon/@1x/footer/mh-Customer-service-default.png" height="47" width="50">
			          客服
			      </mt-tab-item>
			      <mt-tab-item id="imformation">
			        <img slot="icon" src="../../../static/css/img/usermoon/@1x/footer/mh-Collection-defulat.png" height="47" width="50">
			       收藏
			      </mt-tab-item>
			      <mt-tab-item id="quiz">
			        <img slot="icon" src="../../../static/css/img/usermoon/@1x/footer/mh-comment.png" height="47" width="50">
			        评论
			      </mt-tab-item>
			      <mt-tab-item id="club">
			        <!-- <img slot="icon" src="../../../static/css/img/usermoon/@1x/footer/mh-house.png" height="47" width="50"> -->
			        预约到店
			      </mt-tab-item>
			 </mt-tabbar>
		</div>
	</div>
</template>
<style>
	.mint-swipe,.mint-swipe-item,.mint-swipe-items-wrap > div.is-active{width:100%;height:200px;background-color: #f00}
	.mint-cell-wrapper{display:block;border:none;}
	.intro .mint-cell-title{height:50px;padding:10px 0;border-bottom:1px solid #eee;}
	.server .mint-cell-value{display: block}
	.server{display:inline-block;}
	.com .dl_bc-biref{
		top:64px;
		 line-height: 23px;
	    font-size: 14px;
	    padding: 10px;
	    border-radius: 10px;
	    min-height: 50px
	}
	.dynamic .mint-cell-wrapper{
		min-height:250px;
		position:relative;
		border:none;
	}
	 .dynamic .kb_cell-time{top:32px;left:60px;}
	 .dynamic .mint-cell-title{position:absolute;top:0;width:100%;}
	 .dynamic .kb_cell-brief{top:45px;}
	 .pic{bottom:0;}
	 #foot{display: none}
	 .mint-tab-item:nth-child(4){
	 	background: -webkit-linear-gradient(left,#f3ac93 5%, #fcd5d9);
   		 color: #fff;

	 }
	  .mint-tab-item:nth-child(4) .mint-tab-item-label{line-height: 58px}
</style>