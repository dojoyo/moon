<template>
	<div id="booking">
		<mt-header fixed title="预约到店">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				提交
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-field label="预约人姓名" placeholder="请输入用户名" type="text"></mt-field>
			<mt-field label="预约人电话" placeholder="请输入邮箱" type="tel" ></mt-field>
			<mt-field label="预约时间" placeholder="请输入密码" type="date" ></mt-field>
		</section>
	</div>
</template>