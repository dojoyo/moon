<template>
	<div id="setting">
		<mt-header fixed title="设置">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-cell title="关于我们" is-link></mt-cell>
			<mt-cell title="用户协议" is-link></mt-cell>
			<mt-cell title="意见反馈" is-link></mt-cell>
			<mt-button type="danger" size="large">退出</mt-button>
		</section>
	</div>
</template>
<style>
	.mint-button--large{
		width:70%;
		margin:0 auto;
	}
</style>