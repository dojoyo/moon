<template>
	<div id="parenting">
		<mt-header title="育儿信息" fixed>
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				<mt-button @click="finish()">完成</mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-radio  v-model="value" :options="options" title="孩子性别"></mt-radio>

			<mt-button @click="openPicker">孩子出生日期</mt-button><span class="birthdaytime"></span>

			<mt-datetime-picker v-model="parenting.baby_birthday"  ref="picker" type="datetime" year-format="{value} 年" month-format="{value} 月" date-format="{value} 日" hour-format="{value}时" minute-format="{value}分" @confirm="handleConfirm"></mt-datetime-picker>

			<mt-field label="你的经期长度" type="number" v-model="parenting.menstruation_time" v-on:input="changetime"></mt-field>

			<span v-show="istime" v-bind:class="{iscorrect:istime}">请输入正常的经期长度</span>

			<mt-field label="你的月经周期" type="number" v-model="parenting.period"  v-on:input="changeperiod"></mt-field>

			<span v-show="isperiod" v-bind:class="{iscorrect:isperiod}">请输入正常的经期周期</span>	

			<mt-field label="你的身高"  type="number" v-model="parenting.height"></mt-field>

			<mt-field label="你的体重"  type="number" v-model="parenting.weight"></mt-field>
			
		</section>
	</div>
</template>
<script>
	export default{
		name:'parenting',
		data(){
			return{
				parenting:{
					'baby_sex':'',
					'baby_birthday':'',
					'menstruation_time':'',
					'period':'',
					'height':'',
					'weight':''

				},
				value:"",
				options:[
					{
						label:'小王子',
						value:'1'
					},
					{
						label:'小公主',
						value:'2'
					}
				],
				istime:false, //设置经期长度
				isperiod:false //设置经期周期
			}
		},
		methods:{
			openPicker(){
				 this.$refs.picker.open();
			},
			handleConfirm:function(){
				console.log(this.parenting.baby_birthday)

				this.parenting.baby_birthday=new Date(this.parenting.baby_birthday)

				//初始化时间格式
				this.parenting.baby_birthday=this.parenting.baby_birthday.getFullYear() + '-' + (this.parenting.baby_birthday.getMonth() + 1) + '-' + this.parenting.baby_birthday.getDate() + ' ' + this.parenting.baby_birthday.getHours() + ':' + this.parenting.baby_birthday.getMinutes() + ':' + this.parenting.baby_birthday.getSeconds(); 

				$('.birthdaytime').text(this.parenting.baby_birthday)
			},
			changetime:function(){
				if(this.parenting.menstruation_time >7 || this.parenting.menstruation_time <0  ||  this.parenting.menstruation_time == ''){
					console.log('请输入正常的经期长度')
					this.istime=true
				}else{
					this.istime=false
				}
				
			},
			changeperiod:function(){
				if(this.parenting.period <20 || this.parenting.period >30 ||  this.parenting.period == ''){
					console.log('请输入正常的经期周期')
					this.isperiod=true
				}else{
					this.isperiod=false
				}
			},
			finish:function(){
				this.$ajax({
					method:'post',
					url:'/api/user/after_pregnancy/update?KB_CODE='+this.code().data.KB_CODE,
					data:{
						baby_sex:this.value,
						baby_birthday:this.parenting.baby_birthday,
						menstruation_time:this.parenting.menstruation_time,
						period:this.parenting.period,
						
					}
				}).then(function(data){
					console.log(data)
				})

				this.$ajax({
					method:'post',
					url:'/api/user/detail/update?KB_CODE='+this.code().data.KB_CODE,
					data:{
						height:this.parenting.height,
						weight:this.parenting.weight
					}
				}).then(function(data){
					console.log('这是身高体重');
					console.log(data)
				})
			}
		}
	}
</script>
<style>
	.mint-cell-title{border:none;}
	a.mint-cell{display:inline-block;}
	.mint-button--default{background: #fff;box-shadow: none;font-size:14px;}
</style>
