<template>
	<div id="inform">
		<mt-header  fixed>
			<router-link to="/home" slot="left">
				<!-- <mt-button icon="back"></mt-button> -->
			</router-link>

			<mt-search slot="left">
			  <mt-cell>
			  </mt-cell>
			</mt-search>

			<router-link to="#" slot="right">
				<span class="icon-msg"></span>
			</router-link>
		</mt-header>
		<section id="Main">
		<!-- 导航栏 -->
			<div class="navbar">
				<mt-navbar v-model="selected">
				  <mt-tab-item id="1">选项一</mt-tab-item>
				  <mt-tab-item id="2">选项二</mt-tab-item>
				  <mt-tab-item id="3">选项三</mt-tab-item>
				</mt-navbar>
					<!-- tab-container -->
				<mt-tab-container v-model="selected">
					  <mt-tab-container-item id="1" class="con1">
					    <mt-cell title="惊奇！为什么外国人不用坐月子呢" >
							<img src="../../../static/images/1.jpg" class="w h200">
						</mt-cell>
						 <mt-cell  title="百伦费主治医生">
					    	<img src="../../../static/images/1.jpg" class="w80 h70 pr10 fl" slot="icon">
					    	<p class="kb_cell-brief tl">
					    		<span>备孕</span> 
					            <i class="ml10 icon-look w20 h20"></i>
					            <span>100</span>
					         </p>
					    </mt-cell>
					  </mt-tab-container-item>
					  <mt-tab-container-item id="2">
					    <mt-cell v-for="n in 4" :title="'测试 ' + n" />
					  </mt-tab-container-item>
					  <mt-tab-container-item id="3">
					    <mt-cell v-for="n in 6" :title="'选项 ' + n" />
					  </mt-tab-container-item>
				</mt-tab-container>
			</div>
			<!-- 弹窗 -->
			<mt-popup v-model="popupVisible" position="middle" class="pt10 stage" @click="stage()">
				<p class="f14 mt10">目前阶段</p>
				<router-link to="/information/preparepregnant" class="f18 mt10 moon_radius tc">备孕</router-link>
				<router-link to="/information/pregnant" class="f18 mt10 moon_radius tc">怀孕</router-link>
				<router-link to="/information/parenting" class="f18 mt10 moon_radius tc">育儿</router-link>
			</mt-popup>
		</section>
	</div>
</template>
<script>
	export default{
		name:'inform',
		data(){
			return{
				selected:'1',
				popupVisible:{}
			}
		},
		mounted:function(){
			this.$ajax({
				method:'get',
				url:'/api/user/user/info?KB_CODE='+this.code().data.KB_CODE	
			}).then(function(data){
					console.log(data)
					if(data.data.pregnancy_status==1 || data.data.pregnancy_status==2 || data.data.pregnancy_status==3){
							$('.stage').css('display','none')
					}
			})
		},
		methods:{
			stage:function(){
				console.log
			}
		}
	}
</script>
<style>
	.con1 .mint-cell-wrapper{display: block}
	.con1 .mint-cell-title{padding:10px;font-size:16px;}
	.mint-popup{width:250px;height:200px;border-radius: 20px}
	.moon_radius{width:200px;height:38px;line-height: 38px;display: block}
	.mint-popup{text-align: -webkit-center}
</style>