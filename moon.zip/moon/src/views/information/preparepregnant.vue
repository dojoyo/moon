<template>
	<div id="preparepregnant">
		<mt-header title="备孕" fixed>
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				<mt-button @click="submit()">完成</mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-field label="最后一次来月经时间" placeholder="请选择" type="date" v-model="preparepregnant.last_menstruation_time"></mt-field>
			<mt-field label="经期长度" placeholder="请填写" type="number" v-model="preparepregnant.menstruation_time" v-on:input="changetime"></mt-field>
			<span v-show="istime" v-bind:class="{iscorrect:istime}">请输入正常的经期长度</span>

			<mt-field label="经期周期" placeholder="请填写" type="number" v-model="preparepregnant.period" v-on:input="changeperiod"></mt-field>
			<span v-show="isperiod" v-bind:class="{iscorrect:isperiod}">请输入正常的经期周期</span>			
			
		</section>
	</div>
</template>
<script>
	export default{
		name:'preparepregnant',
		data(){
			return{
				preparepregnant:{
					'last_menstruation_time':'',
					'menstruation_time':'',
					'period':''
				},
				istime:false, //设置经期长度
				isperiod:false //设置经期周期
			}
		},
		methods:{
			changetime:function(){
				if(this.preparepregnant.menstruation_time >7 || this.preparepregnant.menstruation_time <0  || this.preparepregnant.menstruation_time == ''){
					console.log('请输入正常的经期长度')
					this.istime=true
				}else{
					this.istime=false
				}
				
			},
			changeperiod:function(){
				if(this.preparepregnant.period <20 || this.preparepregnant.period>30 ||  this.preparepregnant.period == ''){
					console.log('请输入正常的经期周期')
					this.isperiod=true
				}else{
					this.isperiod=false
				}
			},
			submit:function(){
				// console.log(thatthis.code().KB_CODE)
				 var that=this
				this.$ajax({
					method:'post',
					url:'/api/user/ready_pregnancy/update?KB_CODE='+this.code().data.KB_CODE,
					data:{
						last_menstruation_time:this.preparepregnant.last_menstruation_time,
						menstruation_time:this.preparepregnant.menstruation_time,
						period:this.preparepregnant.period
					}
				}).then(function(data){
					console.log(data)
					if(data.data.err_code==0){
						alert('提交成功,正在跳转....')
						setTimeout(function(){
							window.location.href="/information"
						},1000)
						
						
					}
				})
			}

		}

	}
</script>
<style>
	.mint-cell-title{border:none;}
	.mint-field .mint-cell-title{width:200px;font-size: 14px}
</style>