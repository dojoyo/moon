<template>
	<div id="pregnant">
		<mt-header title="怀孕信息" fixed>
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				<mt-button @click="finish()">完成</mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-radio   v-model="value"  :options="options" @change="check" class="border-bot">  
        </mt-radio>  
			<mt-field label="你的预产期" placeholder="请选择" type="date" v-model="date" class="border-bot"></mt-field>			
		</section>
	</div>
</template>
<script>
	export default{
		name:'pregnant',
		data(){
			return{
				pregnant:{
					'due_date':'',//预产期
					'pregnancy_date':''//怀孕日期
				},
				date:'',//判断时间
				//是判断是否知道预产期 
				value:"",//接收options的value值
	            options : [
		            {  
			            label: '是',  
			            value: '1'
		            },  
		            {  
			            label: '否',  
			            value: '2' 
		            }
	            ]  
			}
		},
		methods:{
			check:function(){
				if(this.value===2){

					$('.mint-cell-text').text('你的末次月经时间')
				}else{
					$('.mint-cell-text').text('你的预产期')
				}
			},
			finish:function(){
				if(this.value==1){
					this.$ajax({
						method:'post',
						url:'/api/user/pregnancy/update?KB_CODE='+this.code().data.KB_CODE,
						data:{

							due_date:this.date
						}
					}).then(function(data){
						console.log('这是value=1')

						$('.mint-field-core').val("")
					})
				}else{
					this.$ajax({
						method:'post',
						url:'/api/user/pregnancy/update?KB_CODE='+this.code().data.KB_CODE,
						data:{

							pregnancy_date:this.date
						}
					}).then(function(data){
						console.log('这是value=2')

						$('.mint-field-core').val("")
				})
			}
		}
	}
}
</script>
<style>
	.mint-cell-wrapper{border:none;}
	a.mint-cell{display:inline-block;}
	.mint-radio-core{width:0;height:0;border:none;}
	.mint-radiolist,.mint-field{width:100%;}

</style>