<template>
	<div id="noresult">
			<mt-header  fixed>
			<router-link to="/home" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>

			<mt-search slot="left">
			  <mt-cell>
			  </mt-cell>
			</mt-search>

			<router-link to="#" slot="right">
				<span class="icon-msg" ></span>
			</router-link>
		</mt-header>
		<section id="main">
			<mt-cell title="没有搜索到相关信息"></mt-cell>
			<p class="p10">
				<span class="recom_type fl">可咨询专家</span>
				<span>
					<router-link to="/home/expertlist" class="recom-title fr">更多</router-link>
				</span>
			</p>
			<div class="border-bot mt30 tl pb20">
				<img src="../../../static/images/1.jpg" class="round-img fl mr10 pl10">
				<p class="name mb10">百伦费 </p>
				<span class="types">全科主治医生/内科医生</span>
				<span class="fr price pr10">10元 /&nbsp;次</span>
			</div>
			<div class="border-bot mt30 tl pb20">
				<img src="../../../static/images/1.jpg" class="round-img fl mr10 pl10">
				<p class="name mb10">百伦费 </p>
				<span class="types">全科主治医生/内科医生</span>
				<span class="fr price pr10">10元 /&nbsp;次</span>
			</div>
			<div class="border-bot mt30 tl pb20">
				<img src="../../../static/images/1.jpg" class="round-img fl mr10 pl10">
				<p class="name mb10">百伦费 </p>
				<span class="types">全科主治医生/内科医生</span>
				<span class="fr price pr10">10元 /&nbsp;次</span>
			</div>
		</section>
	</div>
</template>
<style>
	.price{margin-top:-20px;}

</style>