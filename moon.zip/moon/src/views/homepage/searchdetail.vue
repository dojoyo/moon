<template>
	<div id="searchdetail">
		<mt-header fixed title="文章详情">
			<router-link to="/home/searchpage" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<div  slot="right" @click="show()">
				<mt-button icon="more"></mt-button>
				<div class="mess" v-show="isshow">
					<router-link to="/notice">
						<img src="../../../static/css/img/usermoon/@1x/mh-new.png" width="20px" height="20px">
						<span>消息</span>
					</router-link>
					<router-link to="/home">
						<img src="../../../static/css/img/usermoon/@1x/nav/mh-Clubhousemh-default.png" width="20px" height="20px">
						<span>消息</span>
					</router-link>
				</div>
			</div>
		</mt-header>
		<section id="main">
			<mt-cell title="坐月子需要注意哪些情况" label="2017-12-31"></mt-cell>
			<div class="art_detail">
				<p class="scription">
					这个简写属性用于一次设置元素字体的两个或更多方面。使用 icon 等关键字可以适当地设置元素的字体，使之与用户计算机环境中的某个方面一致。注意，如果没有使用这些关键词，至少要指定字体大小和字体系列。
					这个简写属性用于一次设置元素字体的两个或更多方面。使用 icon 等关键字可以适当地设置元素的字体，使之与用户计算机环境中的某个方面一致。注意，如果没有使用这些关键词，至少要指定字体大小和字体系列。
					<img src="../../assets/logo.png">
				</p>
				<div  :style="{ textAlign: ['-webkit-right', 'right'],padding:['0 10px 15px 0'] }">
				<div class="icon">
					<label class="icon-like">
						<input type="checkbox" name="" value="">
						<span></span>
						<em>1000</em>
					</label>
				</div>
				<div class="icon">
					<label class="icon-browe">
						<input type="checkbox" name="" value="">
						<span></span>
						<em>1000</em>
					</label>
				</div>
			</div>
			<div class="clear"></div>
			
			</div>
			<div class="recom">
				<p class="recom-title">相关文章推荐</p>
				<mt-cell title="标题文字"></mt-cell>
				<mt-cell title="标题文字"></mt-cell>
				<mt-cell title="标题文字"></mt-cell>
				<mt-cell title="标题文字"></mt-cell>
				<mt-cell title="标题文字"></mt-cell>
				<mt-button type="primary" size="small" plain :style="{marginTop:['20px']}" @click.native="goback()">返回首页</mt-button>
			</div>
		</section>
	</div>
</template>
<script>
	export default{
		name:'searchdetail',
		data(){
			return{
				isshow:false,
				flag:1
			}
		},
		methods:{
			show:function(){
				if(this.flag==1){
					this.isshow=true
					this.flag=2
				}else{
					this.isshow=false;
					this.flag=1
				}
			},
			goback:function(){
				this.$router.replace({path:'/home'})
			}
		}
	}
</script>
<style>
	#searchdetail{min-height: 950px}
	.mess{
		text-align:center;
		width: 60px;
	    height: 80px;
	    background: #fff;
	    position: absolute;
	    border-radius: 10px;
	    box-shadow: 1px 0px 6px 1px #ccc;
	    right: 3px;
	    padding:0 20px;
	}
	.mess img{
		vertical-align: bottom;
		margin-right:5px;
	}
	a.router-link-active{
		display:block;
		margin:10px 0;
		color:#999;
		text-decoration: none
	}
	.mint-cell{
		text-align:left;
		height:70px;
		border-bottom: 1px solid #eee
	}
	.mint-cell-text{
		font:20px microsoft yahei;
		display: block;
		padding-bottom: 10px
	}
	.art_detail{
		text-align:left;
		
	}
	.scription{
		border-bottom:1px solid #eee;
		padding-bottom: 10px
	}
	input[type="checkbox"]{
		width:0;
	}
	.recom{margin-top:20px;}
	.recom .mint-cell{height:30px;font-size: 14px;position:relative;}
	.recom .mint-cell .mint-cell-text{font-size:16px;position: absolute;}
	.clear{width:100%;height:10px;background: #f5f4f4}
</style>