<template>
	<div id="searchpage">
		<mt-header  fixed>
			<router-link to="/home" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>

			<mt-search slot="left">
			  <mt-cell>
			  </mt-cell>
			</mt-search>

			<router-link to="#" slot="right">
				<span class="icon-msg"></span>
			</router-link>
		</mt-header>
		<section id="main">
			<mt-cell title="坐月子需要注意什么" label="不知道不知道不知道不知道不知道啊不知道不知道不知道不知道不知道啊不知道不知道不知道不知道不知道啊" >
			</mt-cell>
			<mt-cell title="坐月子需要注意什么" label="不知道不知道不知道不知道不知道啊不知道不知道不知道不知道不知道啊不知道不知道不知道不知道不知道啊" >
			</mt-cell>
			<mt-cell title="坐月子需要注意什么" label="不知道不知道不知道不知道不知道啊不知道不知道不知道不知道不知道啊不知道不知道不知道不知道不知道啊" to="">
			</mt-cell>
		</section>
	</div>
</template>
<script>
	export default{
		name:'searchpage',
		data(){
			return{

			}
		}
	}
</script>
<style>

	.mint-cell-wrapper{text-align:left;}
	.mint-cell:first-child,.mint-cell:last-child{border:none;}
	.mint-cell-text{display: block;padding-bottom: 5px}
	.mint-cell-label{line-height: 20px}
</style>