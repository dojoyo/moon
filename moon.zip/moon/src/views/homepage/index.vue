<template>
	<div id="search">
		
			<mt-header title="首页" fixed></mt-header>
			<section id="Main">
				<div class="title tc">知识库</div>
			<mt-search  cancel-text="取消" placeholder="搜索" @keyup.enter.native="search()"  v-model="keyword">
			</mt-search>

			<div class="record">
				<p class="rec-title">历史记录</p>
				<span class="keyword">月经不掉</span>
				<span class="keyword">月经不掉</span>
				<span class="keyword">月经不掉</span>
				<span class="keyword">妇科疾病怎么治</span>
				<span class="keyword">月经不掉</span>
				<span class="keyword">月经不掉</span>
			</div>
			<div class="record">
				<p class="rec-title">热门搜索</p>
				<span class="keyword">月经不掉</span>
				<span class="keyword">月经不掉</span>
				<span class="keyword">月经不掉</span>
				<span class="keyword">妇科疾病怎么治</span>
				<span class="keyword">月经不掉</span>
				<span class="keyword">月经不掉</span>
			</div>
			</section>
			
		</div>

</template>
<script>
	export default{
		name:'search',
		data(){
			return{
				keyword:''
			}
		},
		methods:{
			search:function(){
		
				this.$router.replace({path:'/home/searchpage'})
			},
			
		}
	}
</script>
<style>
	.title{color:#ff9194;font-size: 20px;padding:50px 0 10px 0;}
	.mint-searchbar{background: transparent;border:1px solid #ccc;border-radius:30px;width:80%;margin:0 auto;padding:3px 10px;}
	.mint-search{height:auto;position: static;}
	.record{text-align: left;padding:20px;}
	.record .rec-title{color:#ff9194;margin-bottom: 20px}
	.keyword{display: inline-block;width:auto;background: #f7f7f7;height:20px;padding:0 10px;line-height: 20px;text-align: center;color:#999;margin:5px;border-radius: 5px;font-size: 14px}
</style>