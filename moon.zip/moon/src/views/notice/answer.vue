<template>
	<div id="answers">
		<section id="main">
			<!-- <div class="nav mb15 border-bot h40">  
			      <mt-button size="small" @click.native.prevent="notice = 'answer'" class="subject">问答</mt-button>  
			      <mt-button size="small" @click.native.prevent="notice = 'inform'">消息</mt-button>   
		    </div> 
		    <div class="page-tab-container">
				<mt-tab-container v-model="notice" swipeable>
					  <mt-tab-container-item id="answer">
					    <mt-cell  v-for="n in 5" title="百伦费" label="请问想一下这种情况怎么办" class="answer">
					    	<img src="../../../static/images/1.jpg" class="round-img fl pr10" slot="icon">
					    	<span class="moon-btnMini-main moon_radius f12 pa">问答中</span>
							<span class="fr f12 moon-biref">2017-12-31</span>
					    </mt-cell>

					  </mt-tab-container-item>
					  <mt-tab-container-item id="inform">
					     <mt-cell  v-for="n in 5" title="订单消息" class="inform">
					     	<span class="fr f12 moon-biref pa">2017-12-31</span>
					    	<img src="../../../static/images/1.jpg" class="round-img fl pr10" slot="icon">
							
							<div class="dl_bc-biref mt10 pa">
								数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
							</div>
					    </mt-cell>
					  </mt-tab-container-item>
				</mt-tab-container>
			</div> -->
			<mt-navbar v-model="notice">
			  <mt-tab-item id="notices">消息</mt-tab-item>
			  <mt-tab-item id="inform">通知</mt-tab-item>
            </mt-navbar>
			<!-- tab-container -->
			<mt-tab-container v-model="notice">
			  <mt-tab-container-item id="notices">
			   			<mt-cell  v-for="n in 5" title="百伦费" label="请问想一下这种情况怎么办" class="answer">
					    	<img src="../../../static/images/1.jpg" class="round-img fl pr10" slot="icon">
					    	<span class="moon-btnMini-main moon_radius f12 pa">问答中</span>
							<span class="fr f12 moon-biref">2017-12-31</span>
					    </mt-cell>
			  </mt-tab-container-item>
			  <mt-tab-container-item id="inform">
			    	<mt-cell  v-for="n in 5" title="订单消息" class="inform">
					     	<span class="fr f12 moon-biref pa">2017-12-31</span>
					    	<img src="../../../static/images/1.jpg" class="round-img fl pr10" slot="icon">
							
							<div class="dl_bc-biref mt10 pa">
								数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
							</div>
					    </mt-cell>
			  </mt-tab-container-item>
			</mt-tab-container>
		</section>
	</div>
</template>
<script>
	export default{
		name:'answers',
		data(){
			return{
				notice:'answer'
			}
		}
	}
</script>
<style>
	#answers{
		position:relative;
		top:-60px;
	}
	.mint-button{
	   
		width:45%;
		
	}
	.answer .mint-cell-wrapper{
		display: flex;
		position:relative;
	}
	.inform .mint-cell-wrapper{
		display: block;
		position:relative;
		min-height: 120px;
		border-bottom: 1px solid #eee;

	}
	.moon_radius{
	    width: 50px;
	    height:20px;
	}
	.inform .mint-cell-text{
		margin-top:17px;
		
	}
	.inform .mint-cell-title{
		border:none;
	}
	.moon-biref{
		right:10px;top:16px;
	}
	.dl_bc-biref{
		top:64px;
		  line-height: 23px;
	    font-size: 14px;
	    padding: 10px;
	    border-radius: 10px;
	    min-height: 80px
	}
</style>