<template>
	<div id="mystatus">
		<mt-header fixed title="我的状态">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<div class="status">
				<mt-cell title="备孕中"></mt-cell>
				<mt-cell title="已怀孕"></mt-cell>
				<mt-cell title="育儿中"></mt-cell>
			</div>
			<p class="p10" style="background:#efeaea">备孕信息</p>
			<mt-field label="最后一次来月经时间" placeholder="请选择" type="date" v-model="birthday"></mt-field>
			<mt-field label="经期长度" placeholder="请选择" type="date" v-model="birthday"></mt-field>
			<mt-field label="经期周期" placeholder="请选择" type="date" v-model="birthday"></mt-field>	
		</section>
	</div>
</template>
<style>
	.mint-cell-wrapper{text-align: center;border:none;}
	.mint-cell-title{
		text-align: -webkit-center
	}
	.status .mint-cell-text{
		display: block;
    width: 200px;
    height: 50px;
    border: 1px solid #ff9194;
    line-height: 50px;
    border-radius: 50px;
    color: #ff9194;
	}
	.mint-field .mint-cell-title{width:200px;text-align: left}
</style>