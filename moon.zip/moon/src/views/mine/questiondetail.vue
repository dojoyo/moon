<template>
	<div id="questiondetail">
		<mt-header  fixed title="问答详情">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				评论
			</router-link>
		</mt-header>
		<section id="Main">
			<h2 class="fn mb10 pl10">问答中
				<span class="moon-seconed f14 ml10">距结束 03:45</span>
			</h2>
			<mt-cell class="card tc">
				<img src="../../../static/images/1.jpg"  slot="icon" class="w50 h50 round-img mb10">
				<p slot="icon" >专家名称</p>
				<h3 class="mt10 mb10" slot="icon" >护士长</h3>
				<p slot="icon" >所属院属:护理科</p>
				<span class="f12 border-bot pb10 w pt10" style="display:block">问答时间已经开始，问答时间为48小时</span>
			</mt-cell>
			<mt-cell>
				<div class="kb_cell dl_otheradvisory">
					<p class="kb_cell-hd"><img src="../../../static/images/1.jpg" class="w60 h60 round-img pl10" ></p>
					<p class="kb_cell-bd p10 dl_advisory-detaile-say">哈哈哈哈</p>
				</div>
			</mt-cell>
			<mt-cell>
				<div class="kb_cell dl_selfadvisory ">
			        <p class="kb_cell-hd">
			        	<img src="../../../static/images/1.jpg" alt="" class="dl_headerImg w50 h50">
			        </p>
			        <p class="kb_cell-bd p10 dl_advisory-detaile-say">天生我才必有用，千金散去还复来！这上两句是什么？</p>
			     </div>
			</mt-cell>
		</section>
	</div>
</template>
<style>
	.mint-cell-wrapper,.mint-cell-value{background: none;border:none;display: block;}
	.card .mint-cell-title{
		width:80%;
		margin:0 auto;
		height:150px;
		border:1px solid #ccc;
		border-radius:10px;
		background: #fafafa;
		padding-top: 10px
	}
</style>