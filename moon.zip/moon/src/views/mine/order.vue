<template>
	<div id="order">
		<mt-header fixed title="预约">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
		</mt-header>
		<section id="main">
			<div class="nav mb15">  
			      <mt-button size="small" @click.native.prevent="order = 'all'" class="subject">全部</mt-button>  
			      <mt-button size="small" @click.native.prevent="order = 'booking'">已预约</mt-button>  
			      <mt-button size="small" @click.native.prevent="order = 'evaluation'">待评价</mt-button> 
			      <mt-button size="small" @click.native.prevent="order = 'done'">已完成</mt-button>  
		    </div> 
		    <div class="page-tab-container">
				<mt-tab-container v-model="order" swipeable>
					  <mt-tab-container-item id="all">
					    <mt-cell >
					    	<span slot="icon">预约时间</span>
					    	<span slot="icon">2017-9-2</span>
					    	<span slot="icon">待完成</span>
					    	<img src="../../../static/images/1.jpg" class="w80 h70 pr10 mt10 pb10">
					    	<span class="f18">出生宝宝十大健康标准</span>
					    	<div class="tr btop pt10">
					    		<span  class="icon-moreColor h20 w20"></span>
					    	</div>
					    </mt-cell>
						 <mt-cell>
					    	<span slot="icon">预约时间</span>
					    	<span slot="icon">2017-9-2</span>
					    	<span slot="icon">已过期</span>
					    	<img src="../../../static/images/1.jpg" class="w80 h70 pr10 mt10 pb10">
					    	<span class="f18">出生宝宝十大健康标准</span>
					    	<div class="tr btop pt10">
					    		<span class="kb_btn kb_btnMini moon_btnMini-href w100">去评价</span>
					    	</div>
					    </mt-cell>
					  </mt-tab-container-item>
					  <mt-tab-container-item id="booking">
					    <mt-cell  title="Psychology 2" v-for="n in 5"></mt-cell>
					  </mt-tab-container-item>
					  <mt-tab-container-item id="evaluation">
					    <mt-cell  title="tab-container evaluation" v-for="n in 5"></mt-cell>
					  </mt-tab-container-item>
					   <mt-tab-container-item id="done">
					    <mt-cell  title="tab-container done" v-for="n in 5"></mt-cell>
					  </mt-tab-container-item>
					  
				</mt-tab-container>
			</div>
		</section>
	</div>
</template>
<script>
	export default{
		name:'order',
		data(){
			return {
				order:'all'
			}
		}
	}
</script>
<style scope>
	.mint-button--default{
		color: #656b79;
	    background-color: #fff;
	    box-shadow: 0 0 0px #b8bbbf;
	    width: 20%;
	    border-bottom: 2px solid #ff9194;
	   margin:0 5px;
	}
	.mint-cell{margin-top:10px;}
	.mint-cell-value{display: block}
	.com{}
</style>