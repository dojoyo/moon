<template>
	<div id="personal">
		<mt-header fixed title="个人资料">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				<mt-button @click="finish">完成</mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			 <mt-cell   class="head_url">
			 	<input type="file" @change="upload" class="head_url" ref="head_url">点击上传图片
		    	<img class="round-img fl pr10" id="imgs" slot="icon">
		    </mt-cell>
		    <mt-field label="昵称" placeholder="未输入" v-model="personal.nick_name" ></mt-field>

			<mt-field label="姓名" placeholder="未输入" type="txet" v-model="personal.real_name"></mt-field>

			<mt-radio   v-model="value"  :options="options" @change="check"  title="请选择你的性别" class="border-bot">  </mt-radio>

			<mt-field label="生日" placeholder="请选择" type="date" v-model="personal.brithday"></mt-field>

			<mt-field label="你的身高" placeholder="请输入你的身高" type="number" v-model="personal.user_detail_info[0].height"></mt-field>

			<mt-field label="你的体重" placeholder="请输入你的体重" type="number" v-model="personal.user_detail_info[0].weight"></mt-field>

			<mt-field label="手机号码" placeholder="请输入你的手机号码" type="number" v-model="personal.phone"></mt-field>
			
		</section>
	</div>
</template>
<script>
	export default{
		name:'personal',
		data(){
			return{
				// head_url:'',
				res:{},
				personal:{
						"nick_name":'',
						"real_name":'',
						"open_id": "",// open_id
				        "phone": "",// 联系电话
				        "password": "",// 密码
				        "head_url": "",// 头像
				        "sex": "",// 性别
				        "city": "",// 城市
				        "brithday": "",// 生日
				        "status": "",// 状态
				        "pregnancy_status": "",// 妊娠状态(1:备孕,2:怀孕中,3:孕后)
				        "user_detail_info": [// 详细数据
				            {
				                "weight": "",// 体重
				                "height": "",// 身高
				                "user_id": "",// 用户id
				                "last_login_time": ""// 最后登录时间
				            }
				        ]
					 },
					 value:"",//接收options的value值
		            options : [
			            {  
				            label: '男',  
				            value: '1'
			            },  
			            {  
				            label: '女',  
				            value: '2' 
			            }
		            ] 
			}
		},
		mounted:function(){
			var that=this
			this.$ajax({
				method:'get',
				url:'/api/user/user/info?KB_CODE='+this.code().data.KB_CODE,
			}).then(function(data){
				console.log('this.personal');
				that.personal=data.data.data;
				console.log(that.personal)
				if(that.personal.sex==0 || that.personal.sex==2){
					that.value="2"
				}else if(that.personal.sex==1){
					that.value="1"
				}
			})

		},
		methods:{
			check:function(){

			},
			upload:function(){
				var uploadImg;
				var file = this.$refs.head_url.files[0];
				console.log(file.path)
				console.log('file')
				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function (e) {
				 	uploadImg=this.result;
					$('#imgs').attr('src',this.result);
					// console.log(this.result)
					// console.log('this.result')
				}
				// this.res = this.$refs.head_url.value ;
				console.log(uploadImg)
				console.log('uploadImg')

                this.res=result;
               
			},
			finish:function(){
					console.log(this.res)
                console.log('this.res')

				//图片上传
				this.$ajax({
					method:'post',
					url:'/api/admin/common/upload_file?',
					params:{
						file_field:'head_url',
						upload_total:1,
						upload_type:1
					},
					data:{
						'head_url':this.res
					}
				}).then(function(upload){
						console.log(upload);
						console.log('upload')
				})

				// //修改用户资料
				this.$ajax({
					method:'post',
					url:'/api/user/user/update?',
					params:{
						KB_CODE:this.code().data.KB_CODE
					},
					data:{

						"nick_name":this.personal.nick_name,
						"real_name":this.personal.real_name,
				        "phone": this.personal.phone,// 联系电话
				        "head_url":this.res,// 头像
				        "sex": this.value,// 性别
				        "brithday": this.personal.brithday,// 生日
				        "user_detail_info": [// 详细数据
				            {
				                "weight": this.personal.user_detail_info[0].weight,// 体重
				                "height":  this.personal.user_detail_info[0].height,// 身高
				            }
				        ]
					}
				}).then(function(data){
					console.log('资料');
					console.log(data)
				})
			}

		}
	}
</script>
<style>
	.mint-cell-wrapper{padding:10px;border:none;}
	a.mint-cell{display:inline-block;}
	.mint-field{width:100%;border-bottom: 1px solid #eee}
	.head_url .mint-cell-value{
		padding: 4px 10px;
	    height: 20px;
	    line-height: 20px;
	    position: relative;
	    cursor: pointer;
	    color: #888;
	    background: #fafafa;
	    border: 1px solid #ddd;
	    border-radius: 4px;
	    overflow: hidden;
	    display: inline-block;
	    display: inline;
	    zoom: 1
	}
	input[type="file"]{
		position: absolute;
	    font-size: 100px;
	    right: 0;
	    top: 0;
	    opacity: 0;
	    filter: alpha(opacity=0);
	    cursor: pointer
	}

</style>
