<template>
	<div id="orderdetail">
		<mt-header  fixed title="订单详情">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>

		</mt-header>
		<section id="Main">
			<mt-cell title="已预约" label="预约成功,请准时到店"></mt-cell>
			<span class="recom-title pl10">预约信息</span>
			<mt-cell title="长大冲">
				<img src="../../../static/images/1.jpg" slot="icon" class="w20 h20">
				<p><span>联系方式</span>123456798910</p>
				<p><span>预约时间</span>2017-0-9 9:90</p>
			</mt-cell>
			<mt-cell title="镖旗">
				<img src="../../../static/images/1.jpg" slot="icon" class="w150 h90">
			</mt-cell>
			<mt-cell>
				<p><span>下单时间</span>123456789201</p>
				<p><span>订单标号</span>123456789201</p>
			</mt-cell>
			<mt-button class="fr mr10">取消预约</mt-button>
		</section>
	</div>
</template>
<style>
	.mint-cell-wrapper,.mint-cell-value{display: block;padding-bottom: 10px}
</style>