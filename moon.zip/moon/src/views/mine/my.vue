<template>
	<div id="my">
		<mt-header fixed title="我的">
			<router-link to="#" slot="left">
				<span class="icon-setting w20 h20 mt5 "></span>
			</router-link>
			<router-link to="#" slot="right">
				<span class="icon-msg w20 h20 mt5  "></span>
			</router-link>
		</mt-header>
		<section id="Main">
			<mt-cell class="moon-myself-title tc pb10">
				<img src="../../../static/images/1.jpg" class="w80 h80" style="border-radius:50%">
				<p class="uname">呵呵</p>
				<p class="checkdetail">查看个人资料</p>
			</mt-cell>
			<mt-cell title="我的订单" value="全部订单" ></mt-cell>
			<mt-cell title="我的状态" is-link>
			  <span>备孕中</span>
			  <img slot="icon" src="../../../static/images/usermoon/@1x/mh-status.png" class="w20 h20">
			</mt-cell>
			<mt-cell title="动态">
			  <span>动态</span>
			  <img slot="icon" src="../../../static/images/usermoon/@1x/mh-dynamic.png" class="w20 h20">
			</mt-cell>
			<mt-cell title="收藏">
			  <span>收藏</span>
			  <img slot="icon" src="../../../static/images/usermoon/@1x/mh-Collection.png" class="w20 h20">
			</mt-cell>
			<mt-cell title="关注">
			  <span>关注</span>
			  <img slot="icon" src="../../../static/images/usermoon/@1x/mh-attention.png" class="w20 h20">
			</mt-cell>
			<mt-cell title="问答历史">
			  <span>问答历史</span>
			  <img slot="icon" src="../../../static/images/usermoon/@1x/mh-history.png" class="h20 w20">
			</mt-cell>
		</section>
	</div>
</template>
<script>
	export default{
		name:'my',
		data(){
			return{
				my:{}
			}
		}

	}
</script>
<style>
	.moon-myself-title .mint-cell-wrapper{
		display: block;
		border:none;
	}
	.moon-myself-title .mint-cell-value{
		display: block;
		padding-bottom: 10px
	}
	.moon-myself-title .uname{
		margin:10px 0;
	}
</style>