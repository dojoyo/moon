<template>
	<div id="collected">
		<mt-header fixed title="收藏">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
			<router-link to="#" slot="right">
				编辑
			</router-link>
		</mt-header>
		<section id="main">
			<!-- <div class="nav mb15">  
			      <mt-button size="small" @click.native.prevent="collected = 'inform'" class="subject">资讯</mt-button>  
			      <mt-button size="small" @click.native.prevent="collected = 'club'">月子会所</mt-button>  
		    </div> 
		    <div class="page-tab-container">
				<mt-tab-container v-model="collected" swipeable>
					  <mt-tab-container-item id="inform" class="inform">
					    <mt-cell  v-for="n in 5" title="百伦费主治医生">
					    	<img src="../../../static/images/1.jpg" class="w80 h70 pr10 fl" slot="icon">
					    	<p class="kb_cell-brief ">
					    		<span>备孕</span> 
					            <i class="ml10 icon-look w20 h20"></i>
					            <span>100</span>
					          </p>
					    </mt-cell>

					  </mt-tab-container-item>
					  <mt-tab-container-item id="club">
					   
					    <mt-cell  v-for="n in 5" title="百伦费主治医生" label="哈哈哈哈">
					    	<img src="../../../static/images/1.jpg" class="w80 h70 pr10 fl" slot="icon">
					    	
					    </mt-cell>

					  </mt-tab-container-item>
				</mt-tab-container>
			</div> -->
			<mt-navbar v-model="collected">
			  <mt-tab-item id="inform">资讯</mt-tab-item>
			  <mt-tab-item id="club">月子会所</mt-tab-item>
            </mt-navbar>
			<!-- tab-container -->
			<mt-tab-container v-model="collected">
			  <mt-tab-container-item id="inform">
			   			<mt-cell  v-for="n in 5" title="百伦费主治医生">
					    	<img src="../../../static/images/1.jpg" class="w80 h70 pr10 fl" slot="icon">
					    	<p class="kb_cell-brief ">
					    		<span>备孕</span> 
					            <i class="ml10 icon-look w20 h20"></i>
					            <span>100</span>
					          </p>
					    </mt-cell>
			  </mt-tab-container-item>
			  <mt-tab-container-item id="club">
			    	<mt-cell  v-for="n in 5" title="百伦费主治医生" label="哈哈哈哈">
					    	<img src="../../../static/images/1.jpg" class="w80 h70 pr10 fl" slot="icon">
					    	
					    </mt-cell>
			  </mt-tab-container-item>
			</mt-tab-container>
		</section>
	</div>
</template>
<script>
	export default{
		name:'collected',
		data(){
			return{
				collected:'inform'
			}
		}
	}
</script>
<style>
	.mint-button--default{
		color: #656b79;
    background-color: #fff;
    box-shadow: 0 0 0px #b8bbbf;
    width: 45%;
    border-bottom: 2px solid #ff9194;
    margin-left: 5px;
    margin-right: 5px;
	}
	.mint-cell-wrapper{display: block}
	.page-tab-container .mint-cell-title{border:none;}
	/*.inform .mint-cell-value{position:absolute;left:100px;bottom:28px;}*/
</style>