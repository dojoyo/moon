<template>
	<div id="concern">
		<mt-header fixed title="关注">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			 <mt-cell   title="护士长" label="所属院所:月子会所" class="p10">
		    	<img src="../../../static/images/1.jpg" class="round-img fl pr10" slot="icon">
		    </mt-cell>
		    
		</section>
	</div>
</template>
<style scope>
	.mint-cell-wrapper{padding:10px;}
	.mint-cell-label{display:block;margin-top: 10px}
</style>