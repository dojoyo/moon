<template>
	<div id="dynamic">
		<mt-header fixed title="动态">
			<router-link to="#" slot="left">
				<mt-button icon="back"></mt-button>
			</router-link>
		</mt-header>
		<section id="Main">
			<div>
				<mt-cell title="hahah" class="dynamic">
					<span class="kb_cell-time pa">8:00</span>
					<span class="w20 h20 icon-moreColor pa" slot="icon" src="../../../static/css/img/usermoon/@1x/mh-Unfolded.png"></span>
					<div class="dl_bc-biref mt10 pa">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
					<img src="../../../static/images/1.jpg" class="w50 h50 round-img" slot="icon">
				</mt-cell>
				<mt-cell title="出生的宝爸的10大健康保障">
				  <img  src="../../../static/images/1.jpg" width="100" height="80" class="pa news-title">
				  <p class="kb_cell-brief pa">2017-03-12 
		            <i class="ml10 icon-look w20 h20"></i>
		            <span>100</span>
		          </p>
				</mt-cell>
			</div>
			<div>
				<mt-cell title="hahah" class="dynamic">
					<span class="kb_cell-time pa">8:00</span>
					<span class="w20 h20 icon-moreColor pa" slot="icon" src="../../../static/css/img/usermoon/@1x/mh-Unfolded.png"></span>
					<div class="dl_bc-biref mt10 pa">
						数据:总评价数量,用户名称,评价时间,评价内容,(该数据需要专家进行审核后方可显示在当前页面中)
					</div>
					<img src="../../../static/images/1.jpg" class="w50 h50 round-img" slot="icon">
				</mt-cell>
				<mt-cell title="出生的宝爸的10大健康保障">
				  <img  src="../../../static/images/1.jpg" width="100" height="80" class="pa news-title">
				  <p class="kb_cell-brief pa">2017-03-12 
		            <i class="ml10 icon-look w20 h20"></i>
		            <span>100</span>
		          </p>
				</mt-cell>
			</div>
		</section>
	</div>
</template>
<style>
	.dynamic .dl_bc-biref{
		top:64px;
		  line-height: 23px;
	    font-size: 14px;
	    padding: 10px;
	    border-radius: 10px;
	    min-height: 80px
	}
	.mint-cell-wrapper{
		min-height:200px;
		position:relative;
		border:none;
	}
	.kb_cell-time{top:32px;left:60px;}
	 .mint-cell-title{position:absolute;top:0;width:100%;}
	 .mint-cell-value{position:relative;width:100%;min-height:200px;}
	 .kb_cell-brief{top:45px;}
	 .news-title{right:10px;top:0;}
	 .icon-moreColor{top:25px;right:25px;}
</style>