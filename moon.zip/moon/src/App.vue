<template>
  <div id="app">
    <!-- <head-nav></head-nav> -->
    <router-view></router-view>
    <foot-nav></foot-nav>
  </div>
</template>

<script>
  // import HeadNav from './components/header'
  import FootNav from './components/footer'
export default {
  name: 'app',
  data(){
    return{

    }
  },
  components:{
    
      FootNav
  }
}
</script>

<style>
#app {
  font-family: microsoft yahei;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 60px;
  min-height: 900px
}
</style>
