// function kb_codes(){
// 	// var code=window.localStorage.getItem(JSON.parse('kb_code'));
// 	var code =JSON.parse(window.localStorage.getItem('kb_code'))
// 	console.log(code)
// }
// setTimeout(function(){
// 	kb_codes()
// },1000)

// exports.install = function (Vue, options){
// 	Vue.prototype.kb_code=function(code){
// 		return code =JSON.parse(window.localStorage.getItem('kb_code'))
// 	}
// }