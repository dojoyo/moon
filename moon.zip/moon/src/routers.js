import Vue from 'vue'
import VueRouter from 'vue-router'
import login from './views/login/login.vue'
import index from './views/homepage/index.vue'
import searchpage from './views/homepage/searchpage.vue'
import forget from './views/login/forget.vue'
import logins from './views/login/logins.vue'
import register from './views/login/register.vue'
import home from './views/homepage/home.vue'
import searchdetail from './views/homepage/searchdetail.vue'
import noresult from './views/homepage/noresult.vue'
import expertlist from './views/quiz/expertlist.vue'
import quiz from './views/quiz/quiz.vue'
import questioningexperts from './views/quiz/questioningexperts.vue'
import expertpage from './views/quiz/expertpage.vue'
import expertinput from './views/quiz/expertinput.vue'
import allcomment from './views/quiz/allcomment.vue'
import expertarticle from './views/quiz/expertarticle.vue'
import notice from './views/notice/notice.vue'
import answer from './views/notice/answer.vue'
import setting from './views/setting/setting.vue'
import mine from './views/mine/mine.vue'
import my from './views/mine/my.vue'
import mystatus from './views/mine/mystatus.vue'
import orderdetail from './views/mine/orderdetail.vue'
import dynamic from './views/mine/dynamic.vue'
import concern from './views/mine/concern.vue'
import personal from './views/mine/personal.vue'
import collected from './views/mine/collected.vue'
import questiondetail from './views/mine/questiondetail.vue'
import order from './views/mine/order.vue'
import information from './views/information/information.vue'
import parenting from './views/information/parenting.vue'
import inform from './views/information/inform.vue'
import pregnant from './views/information/pregnant.vue'
import preparepregnant from './views/information/preparepregnant.vue'
import clubs from './views/club/clubs.vue'
import club from './views/club/club.vue'
import clubdetail from './views/club/clubdetail.vue'
import detailedpackage from './views/club/detailedpackage.vue'
import cluballcomment from './views/club/allcomment.vue'
import introduction from './views/club/introduction.vue'
import booking from './views/club/booking.vue'
import comment from './views/club/comment.vue'
Vue.use(VueRouter)
const routers=[
   {
      path: '/',
      component:login,
      redirect:'/logins',
      children:[
          {
            path:'/logins',
            name:'登录',
            component:logins
          },
          {
            path:'/login/forget',
            name:'重置密码',
            component:forget
          },
          {
            path:'/login/register',
            name:'注册账号',
            component:register
          },
      ]
    },
    {
      path: '/home',
      component: home,
      redirect:'/index',
      children:[
        {
          path:'/index',
          name:'主页',
          component:index
        },
        {
          path:'/home/searchpage',
          name:'搜索页',
          component:searchpage
        },
        {
          path:'/home/searchdetail',
          name:'搜索详情页',
          component:searchdetail
        },
         {
          path:'/home/noresult',
          name:'没有搜索结果',
          component:noresult
        },
        {
          path:'/home/expertlist',
          name:'问答模块',
          component:expertlist
        }
        ]
    },
    {
      path:'/quiz',
      name:'问答',
      component:quiz,
      redirect:'/expertlist',
      children:[
          {
            path:'/expertlist',
            name:'专家列表',
            component:expertlist
          },
           {
            path:'/quiz/expertpage',
            name:'专家主页',
            component:expertpage
          },
          {
            path:'/quiz/expertinput',
            name:'提问',
            component:expertinput
          },
          {
            path:'/quiz/allcomment',
            name:'全部评论',
            component:allcomment
          },
          {
            path:'/quiz/expertarticle',
            name:'专家文章',
            component:expertarticle
          },
          {
            path:'/quiz/questioningexperts',
            name:'提问专家',
            component:questioningexperts
          }
      ]
    },
    {
      path:'/notice',
      name:'消息',
      component:notice,
      redirect:'/answer',
      children:[
          {
            path:'/answer',
            name:'问答',
            component:answer
          }
      ]
    },
    {
      path:'/mine',
      name:'我',
      component:mine,
      redirect:'/my',
      children:[
         {
            path:'/my',
            name:'我的',
            component:my
          },
          {
            path:'/mine/mystatus',
            name:'我的状态',
            component:mystatus
          },
           {
            path:'/mine/concern',
            name:'关注',
            component:concern
          },
          {
            path:'/mine/personal',
            name:'个人资料',
            component:personal
          },
           {
            path:'/mine/dynamic',
            name:'动态',
            component:dynamic
          },
          {
            path:'/mine/collected',
            name:'收藏',
            component:collected
          },
          {
            path:'/mine/order',
            name:'预约',
            component:order
          },
          {
            path:'/mine/orderdetail',
            name:'订单详情',
            component:orderdetail
          },
          {
            path:'/mine/questiondetail',
            name:'问答详情',
            component:questiondetail
          }
      ]
    },
    {
      path:'/information',
      name:'资讯',
      component:information,
      redirect:'/information/inform',
      children:[
         {
          path:'/information/parenting',
          name:'育儿信息',
          component:parenting
        },
         {
          path:'/information/pregnant',
          name:'怀孕',
          component:pregnant
        },
         {
          path:'/information/preparepregnant',
          name:'备孕',
          component:preparepregnant
        },
        {
          path:'/information/inform',
          name:'资讯首页',
          component:inform
        }
      ]
    },
    {
      path:'/clubs',
      name:'月子会所',
      component:clubs,
      redirect:'/club',
      children:[
          {
            path:'/club',
            name:'会所',
            component:club
          },
          {
            path:'/club/clubdetail',
            name:'月子会所详情',
            component:clubdetail
          },
          {
            path:'/club/detailedpackage',
            name:'套餐详细',
            component:detailedpackage
          },
          {
            path:'/club/cluballcomment',
            name:'全部评论',
            component:cluballcomment
          },
          {
            path:'/club/booking',
            name:'预定',
            component:booking
          },
          {
            path:'/club/introduction',
            name:'简介',
            component:introduction
          },
          {
            path:'/club/comment',
            name:'评论',
            component:comment
          }
      ] 
    },
    {
      path:'/setting',
      name:'设置',
      component:setting
    }
]

export default routers