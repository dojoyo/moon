<template>
  <div id="head">
    <mt-header fixed title="月子">
    <router-link to="/" slot="left">
      <mt-button icon="back"></mt-button>
    </router-link>
    </mt-header>
  </div>
</template>
<script>
  export default{
    name:'head',
    data(){
      return{

      }
    }
  }
</script>
<style>
  
</style>
