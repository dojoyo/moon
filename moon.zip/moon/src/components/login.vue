<template>
	<div id="login">
		<mt-field label="用户名" placeholder="请输入用户名" v-model="user.name"></mt-field>
		<mt-field label="密码" placeholder="请输入密码" v-model="user.pass"></mt-field>
		<mt-cell title="忘记密码" to="#" is-link class="forget" value="忘记密码"></mt-cell>
		<mt-cell title="注册账号" to="#" is-link class="register"></mt-cell>
		<!-- <mt-button type="danger"  @click="submit()" class="submit">登录</mt-button> -->
	</div>
</template>
<script>
	export default{
		data(){
			return{
				user:{
					"name":'',
					'pass':''
				}
			}
		}
	}
</script>
<style>
	.mint-cell-wrapper{border-bottom:1px solid #eee;background-image:none;}
	.mint-cell:first-child .mint-cell-wrapper{background-origin: none}
	.submit{margin-top:30px;width:80%;}
</style>
