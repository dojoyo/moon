<template>
  <div id="foot">
    <mt-tabbar fixed>
      <mt-tab-item id="homepage">
        <img slot="icon" src="../../static/css/img/usermoon/@1x/nav/mh-home-click.png" height="47" width="50">
          首页
      </mt-tab-item>
      <mt-tab-item id="imformation">
        <img slot="icon" src="../../static/css/img/usermoon/@1x/nav/mh-Information-default.png" height="47" width="50">
        资讯
      </mt-tab-item>
      <mt-tab-item id="quiz">
        <img slot="icon" src="../../static/css/img/usermoon/@1x/nav/mh-queation-default.png" height="47" width="50">
        问答
      </mt-tab-item>
      <mt-tab-item id="club">
        <img slot="icon" src="../../static/css/img/usermoon/@1x/nav/mh-Clubhousemh-default.png" height="47" width="50">
        会所
      </mt-tab-item>
      <mt-tab-item id="mine">
        <img slot="icon" src="../../static/css/img/usermoon/@1x/nav/mh-mine-defulat.png" height="47" width="50">
        我的
      </mt-tab-item>
    </mt-tabbar>
  </div>
</template>
