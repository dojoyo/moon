
// import login from 'views/login/login.vue'

// const _import = require('./_import_' + process.env.NODE_ENV)

// const routers=[
//    {
//       path: '/',
    
//       component: login,
//       name:"login",
//       children:[
//           {
//             path:'forget',
//             name:'重置密码',
//             component:_import('login/forget')
//           }
//       ]
//     }
// ]
// export default routers