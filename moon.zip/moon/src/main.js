// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import VueRouter from 'vue-router'
import App from './App'
import routers from './routers'
import Mint from 'mint-ui'
import 'mint-ui/lib/style.css'
import VueResource from 'vue-resource'
import axios from 'axios'
// import kb_code from './store/kb_code.js'

Vue.use(VueRouter)

Vue.use(VueResource)

// Vue.use(kb_code)

Vue.prototype.$ajax = axios

Vue.prototype.code=function(code){

	 var code = JSON.parse(window.localStorage.getItem('kb_code'))
	
	 return code
	  
}


const router = new VueRouter({
  mode: 'history',
  routes: routers
})

Vue.use(Mint)

Vue.config.productionTip = false


/* eslint-disable no-new */
new Vue({
  router,
  render:h=> h(App)
}).$mount('#app')